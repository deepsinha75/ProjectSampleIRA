﻿using System;
using System.Collections.Generic;
using System.Text;
using iCRA.Interface;

namespace iCRA.BL
{
    class ActionMaster : IMaster
    {
        public ActionMaster()
        {

        }

        IList<string> IMaster.GetCodingMaster()
        {
            throw new NotImplementedException();
        }
    }
}
