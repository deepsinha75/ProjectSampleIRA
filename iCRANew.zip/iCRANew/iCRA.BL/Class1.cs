﻿using System;

namespace iCRA.BL
{
    public class Class1
    {
    }
}
