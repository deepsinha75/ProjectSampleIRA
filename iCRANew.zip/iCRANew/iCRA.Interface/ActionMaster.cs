﻿using System;
using System.Collections.Generic;
using System.Text;


namespace iCRA.Interface
{
    public interface IMaster
    {
        IList<string> GetCodingMaster();
        
    }
}
