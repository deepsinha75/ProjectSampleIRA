﻿using System;

namespace iCRA.Interface
{
    public class Class1
    {
    }
}
