﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;

using log4net.Repository;
using System.Reflection;

namespace iCRA.Logger
{
    public static class Logger
    {
        //This property should be used to write values to file (.txt).
        private static ILog _logger_general;

        //This property should be used to push information to MSMQ server.
        private static ILog _logger_file_reader;

        //This property should be used to push information to MSMQ server.
        private static ILog _logger_data_cache;

        //This property should be used to push information to MSMQ server.
        private static ILog _logger_auto_allocation;

        //This property should be used to push information to MSMQ server.
        private static ILog _logger_simple_report;

        //This property should be used to push information to MSMQ server.
        private static ILog _logger_mis_report;

        //This property should be used to push information to MSMQ server.
        private static ILog _logger_inventory_upload;

        static Logger()
        {
            // This property reads information from Log4Net.config setting for FileLogger.
            _logger_general = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            // This property reads information from Log4Net.config setting for MSMQLogger.
           // _logger_file_reader = LogManager.GetLogger("Logger_FileReader");

            // This property reads information from Log4Net.config setting for MSMQLogger.
           // _logger_data_cache = LogManager.GetLogger("Logger_DataCache");

          
            // Important.
           // log4net.Config.XmlConfigurator.Configure();

            ILoggerRepository repository = log4net.LogManager.GetRepository(Assembly.GetCallingAssembly());

          //  var fileInfo = new FileInfo(@"log4net.config");

            log4net.Config.XmlConfigurator.Configure(repository); // , fileInfo); // ;  ;

        }

        #region Methods to write log to a File (.txt)

        public static void Info(object message)
        {
            if (_logger_general.IsInfoEnabled)
                _logger_general.Info(message);
        }

        public static void Warn(object message)
        {
            if (_logger_general.IsWarnEnabled)
                _logger_general.Warn(message);
        }

        public static void Debug(object message)
        {
            if (_logger_general.IsDebugEnabled)
                _logger_general.Debug(message);
        }

        public static void Error(object message)
        {
            if (_logger_general.IsErrorEnabled)
                _logger_general.Error(message);
        }

        public static void Fatal(object message)
        {
            if (_logger_general.IsFatalEnabled)
                _logger_general.Fatal(message);
        }

        #endregion

        #region Methods to push log to File Reader .

        public static void Info(Format_FileReader message)
        {
            if (_logger_file_reader.IsInfoEnabled)
                _logger_file_reader.Info(message);
        }

        public static void Warn(Format_FileReader message)
        {
            if (_logger_file_reader.IsWarnEnabled)
                _logger_file_reader.Warn(message);
        }

        public static void Debug(Format_FileReader message)
        {
            if (_logger_file_reader.IsDebugEnabled)
                _logger_file_reader.Debug(message);
        }

        public static void Error(Format_FileReader message)
        {
            if (_logger_file_reader.IsErrorEnabled)
                _logger_file_reader.Error(message);
        }

        public static void Fatal(Format_FileReader message)
        {
            if (_logger_file_reader.IsFatalEnabled)
                _logger_file_reader.Fatal(message);
        }

        #endregion


    }

    /// <summary>
    /// New class for FileFormat
    /// </summary>
    public class Format_FileReader
    {
        public Format_FileReader()
        {
            Send_Email_To = new List<string>();
        }

        public string File_Name { get; set; }

        public string File_Path { get; set; }

  
        public List<string> Send_Email_To { get; set; }
    }
}
