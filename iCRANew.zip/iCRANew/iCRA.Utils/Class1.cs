﻿using System;

namespace iCRA.Utils
{
    public class Class1
    {
    }
}
