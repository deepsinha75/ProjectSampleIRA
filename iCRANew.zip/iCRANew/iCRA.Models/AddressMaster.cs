﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace iCRA.Models
{
    class AddressMaster
    {
            public int FileId
            {
              get; set;
            }
            public int AddressMasterId
            {
             get; set;
            }
            string strNewProviderAddress1 = string.Empty;

            public string NewProviderAddress1
            {
             get; set;
            }

            string strNewProviderAddress2 = string.Empty;

            public string NewProviderAddress2
            {
                get; set;
            }
            string strNoChanges = string.Empty;

            public string NoChanges
            {
                 get; set;
            }
            string strNewProviderCity = string.Empty;

            public string NewProviderCity
            {
                get; set;
            }

            public string NewProviderState
            {
                get; set;
            }
         
            public int NewProviderZip
            {
                get; set;
            }
          
            public string ProviderNPI
            {
                get; set;
            }
            public string AddressType
            {
                get; set;
            }

            public string AddressTypeName
            {
                get; set;
            }

            public string ContactType
            {
                get; set;
            }
            string strProviderAddress1 = string.Empty;

            public string ProviderAddress1
            {
                get; set;
            }
       

            public string ProviderAddress2
            {
                 get; set;
            }
     

            public string ProviderCity
            {
                 get; set;
            }

         
            public string ProviderState
            {
                 get; set;
            }

            public int ProviderZip
            {
                get; set;
            }

          
            public string ProviderPhone
            {
                get; set;
            }

            string strTaxanomyCode = string.Empty;

            public string TaxanomyCode
            {
                 get; set;
            }

            string strPrimaryContactLastName = string.Empty;

            public string PrimaryContactLastName
            {
                get; set;
            }

            string strPrimaryContactFirstName = string.Empty;

            public string PrimaryContactFirstName
            {
                get { return strPrimaryContactFirstName; }
                set { strPrimaryContactFirstName = value; }
            }

            string strPrimaryContactPhone = string.Empty;

            public string PrimaryContactPhone
            {
                get { return strPrimaryContactPhone; }
                set { strPrimaryContactPhone = value; }
            }

            string strPrimaryContactEmail = string.Empty;

            public string PrimaryContactEmail
            {
                get { return strPrimaryContactEmail; }
                set { strPrimaryContactEmail = value; }
            }

            string strSecondaryContactLastName = string.Empty;

            public string SecondaryContactLastName
            {
                get { return strSecondaryContactLastName; }
                set { strSecondaryContactLastName = value; }
            }

            string strSecondaryContactMiddleName = string.Empty;

            public string SecondaryContactMiddleName
            {
                get { return strSecondaryContactMiddleName; }
                set { strSecondaryContactMiddleName = value; }
            }


            string strSecondaryContactFirstName = string.Empty;

            public string SecondaryContactFirstName
            {
                get { return strSecondaryContactFirstName; }
                set { strSecondaryContactFirstName = value; }
            }

            string strSecondaryContactPhone = string.Empty;

            public string SecondaryContactPhone
            {
                get { return strSecondaryContactPhone; }
                set { strSecondaryContactPhone = value; }
            }

            string strSecondaryContactEmail = string.Empty;

            public string SecondaryContactEmail
            {
                get { return strSecondaryContactEmail; }
                set { strSecondaryContactEmail = value; }
            }
            string strSecondaryContactFax = string.Empty;

            public string SecondaryContactFax
            {
                get { return strSecondaryContactFax; }
                set { strSecondaryContactFax = value; }
            }
            string strSpecialHandlingCode = string.Empty;

            public string SpecialHandlingCode
            {
                get { return strSpecialHandlingCode; }
                set { strSpecialHandlingCode = value; }
            }
            string strSpecialHandlingInstruction = string.Empty;

            public string SpecialHandlingInstruction
            {
                get { return strSpecialHandlingInstruction; }
                set { strSpecialHandlingInstruction = value; }
            }

            string strEMR = string.Empty;

            public string EMR
            {
                get { return strEMR; }
                set { strEMR = value; }
            }

            string strLOB = string.Empty;

            public string LOB
            {
                get { return strLOB; }
                set { strLOB = value; }
            }
            bool blIsActive = false;

            public bool IsActive
            {
                get { return blIsActive; }
                set { blIsActive = value; }
            }

            string strFax = string.Empty;

            public string Fax
            {
                get { return strFax; }
                set { strFax = value; }
            }

            int lintProviderCount = 0;
            public int ProviderCount
            {
                get { return lintProviderCount; }
                set { lintProviderCount = value; }
            }
            int lintAddressID = 0;
            public int AddressID
            {
                get { return lintAddressID; }
                set { lintAddressID = value; }
            }

            int iIsContractAvaliable = 0;
            public int IsContractAvaliable
            {
                set { iIsContractAvaliable = value; }
                get { return iIsContractAvaliable; }
            }

            string strProviderContractNoXML = string.Empty;
            public string ProviderContractNoXML
            {
                set { strProviderContractNoXML = value; }
                get { return strProviderContractNoXML; }
            }
        }
    
}
