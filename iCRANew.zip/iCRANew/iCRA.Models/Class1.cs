﻿using System;

namespace iCRA.Models
{
    public class Class1
    {
    }
}
