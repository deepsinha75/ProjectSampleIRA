﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iCRA.JWT
{
    [Serializable]
    public class JWT_Token_Info
    {
        public JWT_Token_Info()
        {
            Clients = new List<Client>();
        }

        public int User_Id { get; set; }

        public string Employee_Code { get; set; }

        public string Full_Name { get; set; }

        public string Role_Name { get; set; }

        public DateTime Login_DateTime { get; set; }

        public List<Client> Clients { get; set; }

        public bool Is_First_Login { get; set; }

        public string Email_Id { get; set; }

        public class Client
        {
            public int Client_Id { get; set; }

            public string Client_Name { get; set; }
        }
    }
}
