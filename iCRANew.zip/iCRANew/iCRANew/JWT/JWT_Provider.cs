﻿using JWT;
using JWT.Algorithms;
using JWT.Serializers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace iCRA.JWT
{
    public class JWT_Provider : IDisposable
    {
        const string _secret = "chnage to encryped format";

        IJwtEncoder _encoder = null;
        IJwtDecoder _decoder = null;


        IJwtAlgorithm _algorithm = null;
        IJsonSerializer _serializer= null;
        IBase64UrlEncoder _urlEncoder = null;
        IDateTimeProvider _provider = null;
        IJwtValidator _validator = null;

        public JWT_Provider()
        {
            _algorithm = new HMACSHA256Algorithm();
            _serializer = new JsonNetSerializer();
            _urlEncoder = new JwtBase64UrlEncoder();
            _encoder = new JwtEncoder(_algorithm, _serializer, _urlEncoder);



            _provider = new UtcDateTimeProvider();
            _validator = new JwtValidator(_serializer, _provider);
            _decoder = new JwtDecoder(_serializer, _validator, _urlEncoder);

        }

        public string Generate_Token(JWT_Token_Info payload) {

            var token = _encoder.Encode(payload, _secret);

            return token;
        }

        public bool Verify_Token(string token) {

            bool flag = false;

            try
            {
                var json = _decoder.Decode(token, _secret, verify: true);

                Console.WriteLine(json);

                flag = true;
            }
            catch (TokenExpiredException)
            {
                // Log in DB
                Console.WriteLine("Token has expired");
            }
            catch (SignatureVerificationException)
            {
                // Log in DB
                Console.WriteLine("Token has invalid signature");
            }
            catch (Exception ex)
            {
                // Log in DB
                Console.WriteLine("Illegal base64 exception");
            }

            return flag;
        }

        public JWT_Token_Info Decode_Token(string token) {

            JWT_Token_Info retVal = null;

            try
            {
                retVal = _decoder.DecodeToObject<JWT_Token_Info>(token, _secret, verify: true);
            }
            catch (TokenExpiredException)
            {
                Console.WriteLine("Token has expired");
            }
            catch (SignatureVerificationException)
            {
                Console.WriteLine("Token has invalid signature");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Illegal base64 exception");
            }

            return retVal;
        }

        public void Dispose()
        {
            _encoder = null;
            _decoder = null;

            _algorithm = null;
            _serializer = null;
            _urlEncoder = null;

            _provider = null;
            _validator = null;
        }
    }
}
