using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace iCRAUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
