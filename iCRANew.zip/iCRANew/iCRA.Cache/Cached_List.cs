﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace iARHelper.Cache
{
    public class Cached_List : IDisposable
    {
        IDatabase _cache = null;

        public Cached_List()
        {
            _cache = Redis_Provider.Connection.GetDatabase();
        }

        public string Get(string key)
        {
            string retVal = null;

            if (_cache.KeyExists(key))
            {
                retVal = _cache.StringGet(key);

                retVal = Convert.ToString(JsonConvert.DeserializeObject(retVal));
            }

            return retVal;
        }

        public void Dispose()
        {
            if (_cache != null)
            {
                _cache = null;
            }
        }
    }
}
