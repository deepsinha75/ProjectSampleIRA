﻿using System;

namespace iCRA.Cache
{
    public class Class1
    {
    }
}
