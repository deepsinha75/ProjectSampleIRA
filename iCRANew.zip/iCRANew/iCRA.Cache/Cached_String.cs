﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace iARHelper.Cache
{
    public class Cached_String : IDisposable
    {
        IDatabase _cache = null;

        public Cached_String()
        {
            _cache = Redis_Provider.Connection.GetDatabase();
        }

        public string Get(string key) {

            string retVal = null;

            if (_cache.KeyExists(key))
            {
                retVal = _cache.StringGet(key);
            }

            return retVal;
        }

        public void Set(RedisKey key, RedisValue value) {

            //if (_cache.KeyExists(key))
            //{
                _cache.StringSet(key, value);
            //}
            //else {
            //    throw new Exception(string.Format("Key <{0}> already exists on Redis Server. Set operation reverted.", key));
            //}
        }

        public void Dispose()
        {
            if (_cache != null)
            {
                _cache = null;
            }
        }
    }
}
